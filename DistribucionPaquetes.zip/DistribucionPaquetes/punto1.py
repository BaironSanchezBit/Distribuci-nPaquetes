import time
import subprocess
from datetime import datetime

def capture_netstat_stats():
    netstat_output = subprocess.check_output(["netstat", "-s"]).decode("utf-8")
    transmitted = received = 0
    lines = netstat_output.split('\n')
    for line in lines:
        if 'InOctets:' in line:
            received = int(line.split()[1])
        elif 'OutOctets:' in line:
            transmitted = int(line.split()[1])
    return transmitted, received

def calculate_and_save_differences(filename, measurement_interval):
    with open(filename, 'r') as file:
        lines = file.readlines()

    transmitted_differences = [(measurement_interval, 0)]
    received_differences = [(measurement_interval, 0)]

    for i in range(1, len(lines) - 1):
        current_line = lines[i].split(',')
        next_line = lines[i + 1].split(',')

        transmitted_diff = abs(int(next_line[1]) - int(current_line[1]))
        received_diff = abs(int(next_line[2]) - int(current_line[2]))

        transmitted_differences.append((measurement_interval * (i + 1), transmitted_diff))
        received_differences.append((measurement_interval * (i + 1), received_diff))

    with open("transmitidos.txt", "w") as f:
        f.write("Intervalo;Diferencia\n")
        for interval, diff in transmitted_differences:
            f.write(f"{interval};{diff}\n")

    with open("recibidos.txt", "w") as f:
        f.write("Intervalo;Diferencia\n")
        for interval, diff in received_differences:
            f.write(f"{interval};{diff}\n")

def main():

    total_runtime = int(input("Ingrese el intervalo de tiempo en segundos: "))

    measurement_interval = 10

    output_file = "medicion_bytes.txt"

    with open(output_file, "w") as f:
        f.write("Intervalo,Bytes Transmitidos,Bytes Recibidos\n")

    time_counter = 0

    for _ in range(total_runtime // measurement_interval):
        transmitted, received = capture_netstat_stats()

        time_counter += measurement_interval

        with open(output_file, "a") as f:
            f.write(f"{time_counter},{transmitted},{received}\n")

        time.sleep(measurement_interval)

    calculate_and_save_differences(output_file, measurement_interval)

if __name__ == "__main__":
    main()