import os

def obtener_tamano_directorio(directory_path):
    files_and_sizes = []
    total_size = 0
    min_size = float('inf')
    max_size = float('-inf')

    for dirpath, _, filenames in os.walk(directory_path):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            try:
                size_bytes = os.path.getsize(filepath)
                size_kb = size_bytes / 1024
                files_and_sizes.append((filename, size_kb))
                total_size += size_kb
                if size_kb < min_size:
                    min_size = size_kb
                if size_kb > max_size:
                    max_size = size_kb
            except FileNotFoundError:
                print("", end="")
            except Exception as e:
                print("", end="")

    mean_size = total_size / len(files_and_sizes) if files_and_sizes else 0

    return files_and_sizes, total_size, min_size, max_size, mean_size

def explorar_directorio_y_seleccionar_archivos(start_path, n=100):
    if not os.path.exists(start_path):
        print("", end="")
        return

    files_and_sizes, total_size, min_size, max_size, mean_size = obtener_tamano_directorio(start_path)
    files_and_sizes.sort(key=lambda x: x[1], reverse=True)  
    selected_files = files_and_sizes[:n]  

    print("Estadísticas:")
    print(f"Suma total de tamaños: {total_size:.2f} KB")
    print(f"Tamaño mínimo: {min_size:.2f} KB")
    print(f"Tamaño máximo: {max_size:.2f} KB")
    print(f"Tamaño medio: {mean_size:.2f} KB")

    with open("grafica.txt", "w") as file:
        file.write("tamaño\n")  
        for filename, size_kb in selected_files:
            file.write(f"{size_kb}\n")  

if __name__ == "__main__":
    explorar_directorio_y_seleccionar_archivos('/home/linuxtrabajos', n=100)